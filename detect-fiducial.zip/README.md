# detect-fiducial Script

Author: Thomas Mitchell
Date: 2023-05-30

## Description
This script utilizes computer vision techniques and an Intel RealSense Depth Camera D435 to detect and track fiducial markers in a video stream. The fiducial markers are identified using the ArUco library, and their poses are estimated using the camera's intrinsic parameters. The script also communicates with an Arduino board via a serial connection to send signals based on the detected markers and depth. 

## Background
The detect-fiducial script is part of a larger project aimed at developing a robot arm capable of scanning and manipulating objects in its surroundings. The specific objective of this project was to enable the robot arm to identify cube-shaped objects using a depth camera and subsequently stack them in descending order of size. To achieve this, an Arduino Uno board, along with a custom shield, was utilized to control and power the electronic components of the robot arm.

## Prerequisites
To run this script, you need to have the following libraries and components installed:

- Python 3.9.0
- OpenCV (cv2) 4.7.0
- NumPy
- pyrealsense2
- ArUco library for OpenCV (cv2.aruco)

You also need to connect an Intel RealSense camera to your computer and ensure it is properly recognized.

## Installation and Setup
1. Install the required libraries by running the following command:
   ```
   pip install opencv-python numpy pyrealsense2
   ```

2. Connect the Intel RealSense camera to your computer.

3. Ensure that the camera's drivers are installed and the camera is functioning properly.

## Usage
1. Save this script as "fiducial.py" in your desired directory.

2. Place two fiducial marker PNG files named "fiducial1.png" and "fiducial2.png" in the same directory as the script.

3. Connect an Arduino board to your computer via a serial port (adjust the port number and baudrate in the script if necessary).

4. Run the script using the following command:
   ```
   python fiducial.py
   ```

5. The script will start streaming from the Intel RealSense camera and display the color and depth frames in separate windows titled "RealSense".

6. Hold the fiducial markers within the camera's view to detect and track them. The detected markers will be highlighted with bounding boxes.

7. The script will estimate the pose (translation and rotation) of the detected markers and display a 3D axis on each marker.

8. If a marker is aligned with the horizontal middle of the frame, the script will send a signal to the Arduino board along with the marker ID and the average depth of the marker.

9. Check the console output for the transmitted signals and verify the Arduino board's response.

10. Press any key to stop the script and close the windows.

Note: You may need to adjust the marker templates, marker sizes, camera parameters, or marker detection thresholds to optimize the detection accuracy for your specific use case.